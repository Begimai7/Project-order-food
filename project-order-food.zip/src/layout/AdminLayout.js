import React from 'react'

export const AdminLayout = () => {
  return (
    <div>AdminLayout</div>
  )
}
